class ToDoTask:
    def __init__(self, task_id='', username='', title='', date='', description=''):
        self.task_id = task_id
        self.username = username
        self.title = title
        self.date = date
        self.description = description
