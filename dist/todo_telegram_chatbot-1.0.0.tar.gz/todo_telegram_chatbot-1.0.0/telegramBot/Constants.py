API_KEY = '5938996823:AAHjOCFKMECQ4I8QovJR94tkLT27p4vVAuk'

HELP_TEXT = 'Én egy olyan bot vagyok, aki a te ToDo listádat tudja vezérelni!\n\n' \
            'Hogyha még soha nem használtál, lépj be a ToDo Hub-ba és ' \
            'próbáld ki a következő parancsok egyikét:\n\n' \
            'Idő - Megtudhatod tőlem a pontos időt!\n\n' \
            'todo - Belépsz a ToDo Hub-ba, ahonnan elérhető az' \
            ' összes jelenleg elérhető funkcióm!\n\n' \
            'Hozzáadás - Addj hozzá a ToDo listádhoz egy saját feladatot! \n\n' \
            'Kiválasztás - Válassz ki egy feladatot a saját ToDo listádról! \n\n' \
            'Megjelenítés - Megjelenítem neked az összes ToDo feladatodat a listádról!\n\n' \
            'Teljesítmény - Megjelenítem neked az eddig elért eredményeidet a ' \
            'teljesített feladataid alapján!\n\n' \
            'Kilépés - Ezzel mindig visszaléphetsz, ha' \
            ' esetleg olyan helyre tévednél, ahova nem akartál!\n\n'

START_TEXT = 'Szia! Miben tudok segíteni? A parancsok megtekintéséhez használd a /help funkciót!'

NONE_USER_NAME_TEXT = 'Úgy néz ki, hogy a felhasználóneved None.' \
                      ' Kérlek állíts be magadnak egy felhasználónevet!'

START_SESSION_TEXT = "Üdvözöllek a ToDo Hub-on! Válassz a megadott opciók közül: \n\n" \
                     "Hozzáadás - Addj hozzá a ToDo listádhoz egy feladatot! \n\n" \
                     "Kiválasztás - Válassz ki egy feladatot a saját ToDo listádról! \n\n" \
                     "Megjelenítés -  Megjelenítem neked az" \
                     " összes ToDo feladatot a listádról! \n\n" \
                     "Teljesítmény - Megjelenítem neked az eddig elért" \
                     " eredményeidet a teljesített feladataid alapján! \n"
